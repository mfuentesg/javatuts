
import it.sauronsoftware.junique.JUnique;

/**
 *
 * @author Marcelo
 */

public class Main {

    public static void main(String[] args) {
        String id = "krupf";
        boolean ejecutando = false;
        try {
            JUnique.acquireLock(id);
            ejecutando = true;
        } catch (Exception ex) {
            System.out.println("la aplicacion ya se encuentra corriendo");
            System.exit(0);
        }
        
        if(ejecutando){
            Frame f = new Frame();
            f.setLocationRelativeTo(null);
            f.setVisible(true);
        }
    }

}